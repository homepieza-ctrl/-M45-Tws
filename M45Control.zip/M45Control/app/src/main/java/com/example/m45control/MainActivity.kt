package com.example.m45control

import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var audio: AudioManager
    private lateinit var vib: Vibrator
    private var eq: Equalizer? = null
    private var gamer = false

    private fun vibrar() =
        vib.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))

    private fun volumen(dir: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        vibrar()
    }

    private fun aplicarModo() {
        try {
            val e = eq ?: Equalizer(0, 0).also { it.enabled = true; eq = it }
            val r = e.bandLevelRange
            val n = e.numberOfBands.toInt()
            for (b in 0 until n) {
                val nivel = when {
                    gamer && b >= n - 2 -> r[1] / 2
                    gamer && b == 0 -> r[0] / 2
                    !gamer && b <= 1 -> r[1] / 2
                    else -> 0
                }
                e.setBandLevel(b.toShort(), nivel.toShort())
            }
        } catch (ex: Exception) {
            Toast.makeText(this, "Tu dispositivo no permite el ecualizador global", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        vib = getSystemService(VIBRATOR_SERVICE) as Vibrator
        val estado = findViewById<TextView>(R.id.estado)

        findViewById<Button>(R.id.btnSubir).setOnClickListener { volumen(AudioManager.ADJUST_RAISE) }
        findViewById<Button>(R.id.btnBajar).setOnClickListener { volumen(AudioManager.ADJUST_LOWER) }
        findViewById<Button>(R.id.btnPower).setOnClickListener {
            vibrar()
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        findViewById<Button>(R.id.btnModo).setOnClickListener {
            vibrar()
            gamer = !gamer
            estado.text = if (gamer) "Modo: Gamer" else "Modo: Música"
            aplicarModo()
        }
    }

    override fun onDestroy() { eq?.release(); super.onDestroy() }
}
